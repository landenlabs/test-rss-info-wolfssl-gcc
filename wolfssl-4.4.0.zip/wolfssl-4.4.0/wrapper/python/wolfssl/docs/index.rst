.. toctree::
    :maxdepth: 2

    installation
    usage
    api
    examples
    licensing
